# Задание: импорт темы из JSON в дев-панели

ТЗ для исполнителя в репозитории. Пользовательская часть (промпт для внешнего ИИ и схема файла)
уже готова и лежит в `TOPIC_IMPORT_PROMPT.md` — реализация должна принимать ровно тот формат.

## Что делаем

Учитель приносит задачник в PDF. Отдаёт его любой ИИ вместе с готовым промптом, получает JSON,
загружает JSON на странице импорта, видит предпросмотр с отрисованными формулами, подтверждает —
тема наполняется условиями и ответами.

Ручного ввода LaTeX нет. Разметку сложности после импорта запускает штатный батч из дев-панели.

## Правила проекта

- Русский язык во всех строках интерфейса.
- `npm run lint` падает на любом warning; перед сдачей прогнать `npm run lint` и `npm run test`.
- Тесты — чистая логика без БД и сети, `tests/*.test.ts`, запуск `tsx --test`.
- Алиас `@/*`, относительных путей не разводить.
- Цвета и радиусы — только через токены (`var(--theme-…)`, классы `ui-*`), хардкода нет.
- Миграций эта задача не требует: новых полей нет.

---

## 1. `lib/topic-import.ts` — разбор и валидация

Чистый модуль без Prisma и сети — вся логика проверок здесь, чтобы её можно было покрыть тестами.

```ts
export const IMPORT_FORMAT_VERSION = 1;
export const MAX_IMPORT_NUMBERS = 300;
export const MAX_CONDITION_LENGTH = 4000;
export const MAX_ANSWER_LENGTH = 2000;

export type ImportNumber = {
  number: number;
  conditionLatex: string;
  answerLatex: string | null;
};

export type ParsedImport = {
  title: string;
  description: string;
  numbers: ImportNumber[];
  warnings: string[];   // из файла, показываем как есть
  issues: string[];     // что отбраковали мы сами
};

export function parseTopicImport(raw: unknown): { ok: true; data: ParsedImport } | { ok: false; error: string };
```

Что проверяет:

- корень — объект, `formatVersion === 1` (иначе понятная ошибка про версию формата);
- `topic.title` и `topic.description` — непустые после `normalizeSingleLineText` /
  `normalizeMultilineText` из `@/lib/utils`, обрезаются по 200 и 1000;
- `numbers` — непустой массив, не длиннее `MAX_IMPORT_NUMBERS`;
- у элемента: `number` — целое 1…9999; `conditionLatex` — непустая строка до 4000;
  `answerLatex` — строка до 2000 либо `null` (пустая строка → `null`);
- повторяющийся `number` — первый выигрывает, остальные уходят в `issues` строкой
  «Номер 12 встречается несколько раз — взят первый»;
- элемент, не прошедший проверку, не роняет импорт: отбрасывается с записью в `issues`;
- `warnings` — массив строк, каждая до 300 символов, максимум 50 штук;
- лишние поля игнорируются молча.

Возвращать `ok: false` только на грубых поломках: не JSON-объект, не та версия, нет ни одного
валидного номера.

**Тесты `tests/topic-import.test.ts`:** валидный минимальный файл; чужая `formatVersion`;
дубликат номера; номер с пустым условием; `answerLatex: ""` → `null`; превышение
`MAX_IMPORT_NUMBERS`; мусор вместо объекта.

---

## 2. `app/api/teacher/topic-import/route.ts` — API

Один POST-роут с двумя режимами. Образец авторизации и лимитов — `app/api/teacher/topics/route.ts`.

```ts
type Body = {
  mode: "preview" | "apply";
  payload: unknown;              // распарсенный JSON из файла
  target:
    | { kind: "existing"; topicId: string }
    | { kind: "new"; theoryFileId: string; homeworkFileId: string };
  overwriteFilled?: boolean;     // перезаписывать непустые условия и ответы, по умолчанию false
};
```

Требования:

- только `UserRole.DEVELOPER`, иначе 401 (как в `topics/route.ts`);
- `enforceApiRateLimit("api:topic-import", user.id, 10, 60_000)`;
- тело больше 2 МБ — отказ с понятным текстом;
- `mode: "preview"` **ничего не пишет в базу**: разбирает payload, читает текущее состояние темы
  и возвращает сводку;
- `mode: "apply"` — та же проверка плюс запись в транзакции.

### Ответ предпросмотра

```ts
{
  title: string;
  description: string;
  totalInFile: number;
  willCreateTopic: boolean;
  willAddNumbers: number;        // номеров, которых в теме нет
  willFillEmpty: number;         // есть номер, условие или ответ пустые
  willOverwrite: number;         // есть номер, поле заполнено и отличается
  untouched: number;             // совпадает с тем, что уже лежит
  sample: ImportNumber[];        // первые 5 — для отрисовки формул
  warnings: string[];
  issues: string[];
}
```

`willOverwrite` — то, ради чего нужен предпросмотр: пользователь видит, сколько ручной работы
затрёт, и только тогда включает `overwriteFilled`.

### Запись

Всё в одной транзакции:

1. `kind: "new"` — создать `Topic` (`displayOrder` = максимальный + 1), проверив, что оба
   `StoredFile` существуют и загружены этим пользователем — как в `topics/route.ts`.
   Схема допускает тему без файлов, но обычный флоу требует оба, и импорт не должен
   создавать темы второго сорта.
2. Номера, которых нет, — создать через `createTopicHomeworkNumbersInBatches`
   (`@/lib/topic-homework-numbers`), `displayOrder` продолжает существующую нумерацию.
3. Существующие номера — обновить `conditionLatex` и `answerLatex`:
   пустое поле заполняется всегда; заполненное — только при `overwriteFilled: true`.
4. `difficulty`, `estimatedMinutes`, `difficultySource` **не трогать никогда** — они живут
   отдельной жизнью, их ставит батч разметки.
5. `answerFile` у номера не трогать.

После записи:

- `revalidateTeacherTopicsData()`, `revalidateStudentTopicsData()`,
  `revalidatePath("/teacher/topics")`, `revalidatePath(\`/teacher/topics/${topicId}\`)`;
- лог `logInfoEvent("topic.import.succeeded", { topicId, created, filled, overwritten })`,
  на отказах — `logWarnEvent("topic.import.rejected", …)`.

Ответ: `{ topicId, created, filled, overwritten, skipped }`.

---

## 3. Интерфейс

### Вкладка

`components/developer-panel.tsx`: в тип `DeveloperPanelTab` добавить `"import"`, в массив `TABS` —
`{ key: "import", label: "Импорт темы" }`. Содержимое вкладки — новый компонент.

### `components/topic-import-panel.tsx`

Клиентский компонент, три состояния: ввод → предпросмотр → результат.

**Ввод**

- Свёрнутый блок «Как получить файл» с текстом промпта и кнопкой «Скопировать промпт»
  (`navigator.clipboard.writeText`, короткое подтверждение «Скопировано»).
  Текст промпта держать одной экспортируемой константой — например,
  `lib/topic-import-prompt.ts`, — чтобы он не разъезжался с `TOPIC_IMPORT_PROMPT.md`.
- Выбор цели: радиокнопки «В существующую тему» (селект тем) или «Создать новую тему»
  (два поля загрузки файлов — теория и ДЗ, через существующий `/api/teacher/uploads`).
- Файл JSON: `<input type="file" accept="application/json,.json">` **или** вставка текста
  в `<textarea>` — второе нужно, когда ИИ выдал ответ в чате и файла нет.
- Кнопка «Проверить файл» → `mode: "preview"`.

**Предпросмотр**

- Плашки со сводкой: добавим N, заполним пустых M, перезапишем K, без изменений L.
- `warnings` из файла и `issues` от валидатора — двумя списками, визуально разными:
  первое сказал ИИ, второе нашли мы.
- Первые 5 задач отрисованы через `<LatexAnswerPreview />` — это и есть проверка, что разметка
  живая: KaTeX подсвечивает битые формулы сам.
- Чекбокс «Перезаписывать уже заполненные условия и ответы», по умолчанию **выключен**.
  Показывать его только когда `willOverwrite > 0`, рядом — предупреждение, что ручные правки
  будут потеряны.
- Кнопки «Импортировать» и «Отменить».

**Результат** — что именно записали, ссылка на тему и подсказка: «Запустите разметку сложности
в разделе Действия, чтобы ИИ-подбор учитывал эти задачи».

---

## Критерии приёмки

1. `npm run lint` и `npm run test` проходят.
2. Файл из `TOPIC_IMPORT_PROMPT.md` (пример в разделе «Формат ответа») импортируется без правок.
3. Режим `preview` не делает ни одной записи в базу — проверяется по логам Prisma или ревью кода.
4. Повторный импорт того же файла при выключенном `overwriteFilled` даёт `overwritten: 0`
   и не портит ранее заполненные условия.
5. Роль TEACHER и STUDENT получают 401 на обоих режимах.
6. Битая формула в файле видна в предпросмотре как ошибка KaTeX, а не как пустое место.

## На будущее, в эту задачу не входит

- Импорт файлов теории и ДЗ прямо из JSON (сейчас — только отдельной загрузкой).
- Картинки и чертежи.
- Разбор ответов из отдельного файла-ключа: сейчас ответы должны приехать в том же JSON.
